const { Schema, model } = require('mongoose');

const PremiumMembersSchema = new Schema({
  userId: { type: String, required: true },
  expiresAt: { type: Date, required: true }
});

module.exports = model('PremiumMembers', PremiumMembersSchema);