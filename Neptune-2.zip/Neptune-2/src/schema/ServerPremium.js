const { Schema, model } = require('mongoose');

const ServerPremiumSchema = new Schema({
guildId: { type: String, required: true },
expiresAt: { type: Date, required: true }
});

module.exports = model('ServerPremium', ServerPremiumSchema); 
