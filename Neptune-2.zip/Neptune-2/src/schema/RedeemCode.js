const { Schema, model } = require('mongoose');

const RedeemCodeSchema = new Schema({
code: String,
target: String,
duration: Number,
createdAt: { type: Date, default: Date.now },
});

module.exports = model('RedeemCode', RedeemCodeSchema);