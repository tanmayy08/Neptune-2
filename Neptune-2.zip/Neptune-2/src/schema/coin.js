const { Schema, model } = require('mongoose');

const UserCoinsSchema = new Schema({
  userId: String,
  coins: {
    type: Number,
    default: 10
  }
});

module.exports = model('UserCoins', UserCoinsSchema);