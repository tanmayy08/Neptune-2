const { Schema, model } = require('mongoose');

const BlacklistedUserSchema = new Schema({
userId: { type: String, required: true },
});

module.exports = model('BlacklistedUser', BlacklistedUserSchema);