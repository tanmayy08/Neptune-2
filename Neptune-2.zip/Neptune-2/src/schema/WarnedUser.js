
const { Schema, model } = require('mongoose');

const WarnedUserSchema = new Schema({
userId: { type: String, required: true },
});

module.exports = model('WarnedUser', WarnedUserSchema);