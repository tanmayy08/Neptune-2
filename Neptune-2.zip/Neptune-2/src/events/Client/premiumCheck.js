const PremiumMembers = require('../../schema/prem');
const ServerPremium = require('../../schema/ServerPremium');

async function checkUserPremiumExpiry(client) {
  const now = new Date();
  const expiredUsers = await PremiumMembers.find({ expiresAt: { $lte: now } });

  expiredUsers.forEach(async (user) => {
    const discordUser = await client.users.fetch(user.userId);
    if (discordUser) {
      await discordUser.send("**Your premium membership has expired. Please renew to continue enjoying premium benefits.**");
      await PremiumMembers.deleteOne({ userId: user.userId });
    }
  });
}

async function checkServerPremiumExpiry(client) {
  const now = new Date();
  const expiredServers = await ServerPremium.find({ expiresAt: { $lte: now } });

  expiredServers.forEach(async (server) => {
    const guild = await client.guilds.fetch(server.guildId);
    if (guild) {
      const owner = await guild.fetchOwner();
      if (owner) {
        await owner.send(`**The premium membership for your server "${guild.name}" has expired. Please renew to continue enjoying premium benefits.**`);
        await ServerPremium.deleteOne({ guildId: server.guildId });
      }
    }
  });
}

module.exports = {
  checkUserPremiumExpiry,
  checkServerPremiumExpiry
};