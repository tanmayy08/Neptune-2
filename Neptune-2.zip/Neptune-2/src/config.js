require("dotenv").config();

module.exports = {
  token: process.env.TOKEN || "", // your bot token
  clientID: process.env.CLIENT_ID || "", // your bot client id
  prefix: process.env.PREFIX || "-", // bot prefix
  ownerID: [], // empty array for owner IDs
  admins: [], // empty array for admin IDs

  SpotifyID: "", // spotify id
  SpotifySecret: "", // spotify secret
  mongourl: "", // MongoDb URL

  embedColor: '#23272A',
  logs: "", // empty logs channel ID
  errorLogsChannel: "", // empty error logs channel ID
  ratelimitlog: "", // empty rate limit log channel ID
  removelog: "", // empty remove log channel ID

  SearchPlatform: process.env.SEARCH_PLATFORM || "youtube music",
  AggregatedSearchOrder: process.env.AGGREGATED_SEARCH_ORDER || "youtube music",

  links: {
    img: process.env.IMG || '', // setup system background image
    support: process.env.SUPPORT || '', // support server invite link
    invite: process.env.INVITE || '', // bot invite link
  },
  
  Webhooks: {
    player_create: process.env.player_create || '',
    player_delete: process.env.player_delete || '',
    server_add: process.env.server_add || '',
  },

  nodes: [
    {
      host: process.env.NODE_HOST || "",
      port: parseInt(process.env.NODE_PORT || ""),
      password: process.env.NODE_PASSWORD || "pwd",
      secure: parseBoolean(process.env.NODE_SECURE || "false"),
    }
  ],
};

function parseBoolean(value) {
  if (typeof value === 'string') {
    value = value.trim().toLowerCase();
  }
  switch (value) {
    case true:
    case "true":
      return true;
    default:
      return false;
  }
}