const { tictactoe } = require("reconlx");

module.exports = {
    name: "tictactoe",
    category: "Fun",
    aliases: ["ttt"],
    description: "Play Tic-Tac-Toe with another user.",
    usage: "tictactoe [@second_player]",
    permissions: [],
    owner: false,
    execute: async (message, args, client) => {
        if (!message.mentions.users.first()) {
            return message.reply({ content: "Please mention another user to play Tic-Tac-Toe with." });
        }

        if (message.mentions.users.first().id === client.user.id) {
            return message.reply({ content: "You cannot play Tic-Tac-Toe with the bot." });
        }

        const game = new tictactoe({
            message: message,
            player_two: message.mentions.members.first(),
        });

        game.start();
    },
};
