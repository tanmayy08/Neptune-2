const { EmbedBuilder } = require("discord.js");
const RedeemCode = require('../../schema/RedeemCode');
const PremiumMembers = require('../../schema/prem');
const ServerPremium = require('../../schema/ServerPremium');

module.exports = {
name: "redeem",
category: "utility",
aliases: ["usecode"],
description: "Redeem a redeem code",
args: true,
usage: "<code>",
userPerms: [],
owner: false,
execute: async (message, args, client, prefix) => {

// Extract the provided code from the command arguments
const code = args[0];

// Find the code in the database
const redeemCode = await RedeemCode.findOne({ code });

if (!redeemCode) {
return message.reply({ content: "Invalid or expired redeem code." });
}

// Get the code details
const { target, duration } = redeemCode;

// Perform actions based on the target
if (target === "user") {
const userId = message.author.id;

// Extend the subscription for the user
const expiryDate = new Date();
expiryDate.setDate(expiryDate.getDate() + duration);

await PremiumMembers.findOneAndUpdate(
{ userId },
{ expiresAt: expiryDate },
{ upsert: true, new: true }
);

const embed = new EmbedBuilder()
.setTitle('Redeem Successful')
.setDescription(`You have successfully redeemed the code.

**Target:** ${target}
**Duration:** ${duration} days`)
.setColor(0x00FF00)
.setTimestamp();

await message.channel.send({ embeds: [embed] });

} else if (target === "guild") {
const guildId = message.guild.id;

// Extend the premium features duration for the guild
const expiryDate = new Date();
expiryDate.setDate(expiryDate.getDate() + duration);

await ServerPremium.findOneAndUpdate(
{ guildId },
{ expiresAt: expiryDate },
{ upsert: true, new: true }
);

const embed = new EmbedBuilder()
.setTitle('Redeem Successful')
.setDescription(`You have successfully redeemed the code.

**Target:** ${target}
**Duration:** ${duration} days`)
.setColor(0x00FF00)
.setTimestamp();

await message.channel.send({ embeds: [embed] });
}

// Optionally, remove the code after use
await RedeemCode.deleteOne({ code });
},
};
