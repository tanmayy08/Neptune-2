const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require("discord.js");

module.exports = {
    name: "membercount",
    category: "Information",
    aliases: ["mc", "mcount"],
    description: "Get total members, humans, and bots in the guild",
    args: false,
    usage: "",
    userPerms: [],
    owner: false,
    execute: async (message, args, client, prefix) => {
        const totalMembers = message.guild.members.cache.size;
        const humanMembers = message.guild.members.cache.filter(member => !member.user.bot).size;
        const botMembers = message.guild.members.cache.filter(member => member.user.bot).size;

        const embed = new EmbedBuilder()
            .setAuthor({ name: `${client.user.username} Member Count Panel`, iconURL: client.user.displayAvatarURL() })
            .setColor("#2f3136")
            .setTitle(`${message.guild.name} - Member Count`)
            .setThumbnail(message.guild.iconURL({ dynamic: true }))
            .setDescription(`Get detailed member statistics of the server`)
            .addFields(
                { name: "👥 Total Members", value: `**${totalMembers}**`, inline: true },
                { name: "👤 Humans", value: `**${humanMembers}**`, inline: true },
                { name: "🤖 Bots", value: `**${botMembers}**`, inline: true }
            )
            .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        message.reply({ embeds: [embed] });
    }
};
