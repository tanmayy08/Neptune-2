const { EmbedBuilder } = require("discord.js");
const RedeemCode = require('../../schema/RedeemCode');

module.exports = {
name: "gen",
category: "Owner",
aliases: [],
description: "Generate redeem codes",
args: true,
usage: "<user/guild> <duration [in days]>",
userPerms: [],
owner: false,
admin: true,
execute: async (message, args, client, prefix) => {

// Check if the arguments are valid
if (args.length < 2) {
return message.reply({ content: "Please provide both the target (user/guild) and the duration in days." });
}

const target = args[0];
const duration = parseInt(args[1]);

if (isNaN(duration)) {
return message.reply({ content: "Duration must be a number representing days." });
}

if (target !== "user" && target !== "guild") {
return message.reply({ content: "Target must be either 'user' or 'guild'." });
}

// Generate a random 4-digit text
const generateRandomText = () => {
return Math.random().toString(36).substring(2, 6).toUpperCase();
};

const randomText = generateRandomText();
const code = `Neptune-${randomText}-${target}-${duration}`;

// Save the code to database
const newCode = new RedeemCode({ code, target, duration });
await newCode.save();

// Delete the command message
message.delete();

// Create the embed message for the generated code
const embed = new EmbedBuilder()
.setTitle('Redeem Code Generated')
.setDescription(`A new redeem code has been generated for **${target}**.

**Code:** \`${code}\`
**Duration:** ${duration} days`)
.setTimestamp();

// Send the embed message
message.channel.send({ embeds: [embed] });
},
};