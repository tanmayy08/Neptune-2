const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: "blacklistremove",
    aliases: ["blremove", "rbl"],
    category: "Owner",
    description: "Removes a user from the blacklist.",
    args: true,
    permission: [],
    owner: false,
    bhenchod: true,
    execute: async (message, args, client, prefix) => {
        const embed = new EmbedBuilder()
            .setColor(client.embedColor);

        if (!args[0]) {
            return message.channel.send({ embeds: [embed.setDescription(`Please provide the user ID.`)] });
        }

        // Check if the user ID is valid
        let user;
        try {
            user = await client.users.fetch(args[0]);
        } catch (error) {
            return message.channel.send({ embeds: [embed.setDescription(`Couldn't find a user with the ID \`${args[0]}\`.`)] });
        }

        // Check if the user is already in the blacklist
        const userIsBlacklisted = await client.db.get(`BlacklistedUser_${user.id}`);
        if (!userIsBlacklisted) {
            return message.channel.send({ embeds: [embed.setDescription(`<@${user.id}> is not blacklisted.`)] });
        }

        // Remove the user from the blacklist
        await client.db.delete(`BlacklistedUser_${user.id}`);
        return message.channel.send({ embeds: [embed.setDescription(`<@${user.id}> has been removed from the blacklist.`)] });
    }
};