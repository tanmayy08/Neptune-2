const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "blacklistadd",
  aliases: ["bladd", "abl"],
  category: "Owner",
  description: "Adds a user to the blacklist.",
  args: true,
  permission: [],
  owner: false,
  bhenchod: true,
  execute: async (message, args, client, prefix) => {
    const embed = new EmbedBuilder()
      .setColor(client.embedColor);

    if (args[0]) {
      try {
        await client.users.fetch(args[0]);
      } catch (error) {
        return message.channel.send({ embeds: [embed.setDescription(`Invalid User Id`)] });
      }
      const userIsBlacklisted = await client.db.get(`blacklist_${args[0]}`);
      if (userIsBlacklisted) {
        return message.channel.send({ embeds: [embed.setDescription(`<@${args[0]}> is already blacklisted.`)] });
      }
      client.db.set(`blacklist_${args[0]}`, true);
      return message.channel.send({ embeds: [embed.setDescription(`<@${args[0]}> has been added to the blacklist.`)] });
    } else {
      return message.channel.send({ embeds: [embed.setDescription(`Please provide the user ID.`)] }).catch(err => console.log(err));
    }
  }
};