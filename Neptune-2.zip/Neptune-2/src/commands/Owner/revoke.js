const { EmbedBuilder } = require("discord.js");
const PremiumMembers = require('../../schema/prem');

module.exports = {
  name: "removePremium",
  description: "Remove a user's premium status.",
  aliases: ["revoke","rp"],  
  args: true,
  userPerms: [],
  owner: false,
  execute: async (message, args, client, prefix) => {
    // Only allow a specific user to use this command
    const authorizedUserId = '991517803700027443';
    if (message.author.id !== authorizedUserId) {
      return message.reply("You are not authorized to use this command.");
    }

    // Get the target user from the mention
    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      return message.reply("Please mention a valid user to remove their premium status.");
    }

    // Remove the premium status from the database
    const result = await PremiumMembers.findOneAndDelete({ userId: targetUser.id });
    if (!result) {
      return message.reply("That user does not have a premium status or it has already been removed.");
    }

    // Confirm the removal of premium status
    const embedMessage = new EmbedBuilder()
      .setColor("#FF4500") // Orangered color to indicate an important action
      .setTitle("Premium Status Removed")
      .setDescription(`Premium status removed from user ${targetUser.username}.`)
      .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }));

    message.reply({ embeds: [embedMessage] });
  },
};