const { Discord, EmbedBuilder } = require("discord.js");
const ms = require("ms"); // Make sure to install ms package using npm

module.exports = {
  name: "noprefixadd",
  aliases: ["npadd", "anp"],
  category: "Owner",
  description: "",
  args: true,
  permissions: [],
  owner: false,
  chomu: false,
  bhenchod: true, // 😉 Be cautious with using slang in your code; it might not be professional.
  execute: async (message, args, client, prefix) => {
    const embed = new EmbedBuilder().setColor(client.embedColor);
    if (args.length < 2) {
      return message.channel.send({
        embeds: [embed.setDescription(`Please mention the user and the duration like <@991517803700027443> 10d`)],
      });
    }
    
    const user = message.mentions.users.first(); // Get the mentioned user
    const duration = args[1]; // Get the duration

    if (!user) {
      return message.channel.send({embeds: [embed.setDescription(`Please mention a valid user`)]});
    }

    const durationInMs = ms(duration);
    if (!durationInMs) {
      return message.channel.send({embeds: [embed.setDescription(`Please provide a valid duration.`)]});
    }

    const expirationDate = Date.now() + durationInMs;
    client.db.set(`noprefix_${user.id}`, expirationDate);

    return message.channel.send({embeds: [embed.setDescription(`<@${user.id}> has been added to my No Prefix List for ${duration}.`)]});
  }
}