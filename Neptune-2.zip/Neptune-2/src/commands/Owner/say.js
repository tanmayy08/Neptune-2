const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require("discord.js");

module.exports = {
    name: "say",
    category: "Owner",
    aliases: ["b"],
    description: "",
    args: false,
    usage: "",
    userPerms: [],
    owner: true,
    execute: async (message, args, client, prefix) => {
    let tanmay = ["991517803700027443","1178572441367363615"];
      if(!tanmay.includes(message.author.id)) return    
  const sayMessage = message.content.split(' ').slice(1).join(' ');
      message.delete();
    if (!sayMessage) {
      return message.reply({content: "Hey developer add some text for me to repeat"})

    }
    if (sayMessage) {
   message.channel.send({content: `${sayMessage}`}), {
      allowedMentions: { parse: ["users"] },
    };
     }
  },
};