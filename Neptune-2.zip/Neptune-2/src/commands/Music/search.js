const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, PermissionFlagsBits, Permissions, ButtonStyle, SelectMenuBuilder } = require("discord.js");
const { convertTime } = require("../../utils/convert");

module.exports = {
    name: "search",
    description: "Search for a song",
    category: "Music",
    aliases: [],
    usage: [`<song>`],
    args: true,
    userPrems: [],
    owner: false,
    player: false,
    inVoiceChannel: true,
    sameVoiceChannel: true,
   execute: async (message, args, client, track) => { 

    const { channel } = message.member.voice;
    if (!message.guild.members.me.permissionsIn(channel).has([PermissionFlagsBits.Connect, PermissionFlagsBits.Speak])) return message.channel.send({embeds: [new EmbedBuilder().setColor(client.embedColor).setDescription(`I don't have enough permissions to connect to your VC. Please give me permission \`CONNECT\` or \`SPEAK\`.`)]});
    if (!message.guild.members.me.permissions.has([PermissionFlagsBits.Connect, PermissionFlagsBits.Speak])) return message.channel.send({embeds: [new EmbedBuilder().setColor(client.embedColor).setDescription(`I don't have enough permissions to execute this command! please give me permission \`CONNECT\` or \`SPEAK\`.`)]});

    let player = message.client.manager.get(message.guildId);
    if(!player)
     player = message.client.manager.create({
        guild: message.guild.id,
        voiceChannel: channel.id,
        textChannel: message.channel.id,
        volume: 80,
        selfDeafen: true,
      }) 
      if(player && player.state !== "CONNECTED") player.connect();

    const query = args.join(" ");
  
    const msg = await message.channel.send({embeds: [new EmbedBuilder().setColor(client.embedColor).setAuthor({name:`Searching For **${query}**, Please Wait`})]})
 
    let s = await player.search(query, message.author);
    switch (s.loadType) {
        case "NO_MATCHES":
                const nomatch = new EmbedBuilder()
                  .setAuthor({name:`No search results found for **${query}**`})
                    .setColor(client.embedColor)
                msg.edit({ embeds: [nomatch] });
                if (!player.playing){
                    player.destroy()
                }
                break;
        case "TRACK_LOADED":
            player.queue.add(s.tracks[0]);
            const embed = new EmbedBuilder()
              .setAuthor({name:`Track Queue`})
    .setDescription(`[${s.tracks[0].title}](${s.tracks[0].uri}) \`${convertTime(s.tracks[0].duration, true)}\` ${s.tracks[0].requester}`)
             .setColor(client.embedColor)

            msg.edit({ embeds: [embed], components: [] });
            if (!player.playing) player.play()
            break;
         case "SEARCH_RESULT":
         const tracks = s.tracks.slice(0, 10);
                    const searched = new EmbedBuilder()
                        .setTitle("Select the track that you want.")
                        .setColor(client.embedColor)

        const notherposeidon3 = new ActionRowBuilder()
      .addComponents(
    new SelectMenuBuilder()
        .setCustomId("help_pop")
        .setPlaceholder('Select Here')
        .addOptions([
          {
              label: `${s.tracks[0].title}`,
              value: 's1',
              description: `${convertTime(s.tracks[0].duration, true)}`,
          },
          {
              label: `${s.tracks[1].title}`,
              value: 's2',
              description: `${convertTime(s.tracks[1].duration, true)}`,
          },
          {
              label: `${s.tracks[2].title}`,
              value: 's3',
              description: `${convertTime(s.tracks[2].duration, true)}`,
            },
            {
              label: `${s.tracks[3].title}`,
              value: 's4',
              description: `${convertTime(s.tracks[3].duration, true)}`,
            },
            {
              label: `${s.tracks[4].title}`,
              value: 's5',
              description: `${convertTime(s.tracks[4].duration, true)}`,
            },
            {
              label: `${s.tracks[5].title}`,
              value: 's6',
              description: `${convertTime(s.tracks[5].duration, true)}`,
            },
           {
            label: `${s.tracks[6].title}`,
             value: `s7`,
             description: `${convertTime(s.tracks[6].duration, true)}`,
           },
          {
            label: `${s.tracks[7].title}`,
             value: `s8`,
             description: `${convertTime(s.tracks[7].duration, true)}`,
           },
          {
            label: `${s.tracks[8].title}`,
             value: `s9`,
             description: `${convertTime(s.tracks[8].duration, true)}`,
           },
          {
            label: `${s.tracks[9].title}`,
             value: `s10`,
             description: `${convertTime(s.tracks[9].duration, true)}`,
           }
        ])
      )

                    await msg.edit({embeds: [searched], components: [notherposeidon3] });
                    const search = new EmbedBuilder()
                    .setColor(client.embedColor);

            const collector = msg.createMessageComponentCollector({
                filter: (f) => f.user.id === message.author.id ? true : false && f.deferUpdate(),
                max: 1,
                time: 60000,
                idle: 60000/2
            });
        collector.on("end", async (collected) => {
                if(msg) await msg.edit({ components: [] })
                                    
            });
            collector.on("collect", async (i) => {
              if(!i.deferred) await  i.deferUpdate();
              if(!player && !collector.ended) return collector.stop();
              if(player.state !== "CONNECTED") player.connect();

              
            if(i.values[0] === "s1") {
      player.queue.add(s.tracks[0]);
                        if(player && player.state === "CONNECTED" && !player.playing && !player.paused && !player.queue.size) await player.play();
 
                        if(msg) await msg.edit({embeds: [search.setAuthor({name:`Track Queue`}).setDescription(`[${s.tracks[0].title}](https://discord.gg/5hr4Ef776k) - ${convertTime(s.tracks[0].duration, true)}`)]})
    } else if(i.values[1] === "s2") {
                    player.queue.add(s.tracks[1]);
                    if(player && player.state === "CONNECTED" && !player.playing && !player.paused && !player.queue.size) await player.play();

                    if(msg) await msg.edit({embeds: [search.setAuthor({name:`Track Queue`}).setDescription(`[${s.tracks[1].title}](https://discord.gg/5hr4Ef776k) - ${convertTime(s.tracks[1].duration, true)}`)]})
            
                } else if(i.values[2] === "s3") {
                    player.queue.add(s.tracks[2]);
                    if(player && player.state === "CONNECTED" && !player.playing && !player.paused && !player.queue.size) await player.play();

                    if(msg) await msg.edit({embeds: [search.setAuthor({name:`Track Queue`}).setDescription(`[${s.tracks[2].title}](https://discord.gg/5hr4Ef776k) - ${convertTime(s.tracks[2].duration, true)}`)]})
            
                } else if(i.values[3] === "s4") {
                    player.queue.add(s.tracks[3]);
                    if(player && player.state === "CONNECTED" && !player.playing && !player.paused && !player.queue.size) await player.play();

                    if(msg) await msg.edit({embeds: [search.setAuthor({name:`Track Queue`}).setDescription(`[${s.tracks[3].title}](https://discord.gg/5hr4Ef776k) - ${convertTime(s.tracks[3].duration, true)}`)]})
            
                } else if(i.values[4] === "s5") {
                    player.queue.add(s.tracks[4]);
                    if(player && player.state === "CONNECTED" && !player.playing && !player.paused && !player.queue.size) await player.play();

                    if(msg) await msg.edit({embeds: [search.setAuthor({name:`Track Queue`}).setDescription(`[${s.tracks[4].title}](https://discord.gg/5hr4Ef776k) - ${convertTime(s.tracks[4].duration, true)}`)]})
            
                } else if(i.values[5] === "s6") {
               player.queue.add(s.tracks[5]);
                    if(player && player.state === "CONNECTED" && !player.playing && !player.paused && !player.queue.size) await player.play();

                    if(msg) await msg.edit({embeds: [search.setAuthor({name:`Track Queue`}).setDescription(`[${s.tracks[5].title}](https://discord.gg/5hr4Ef776k) - ${convertTime(s.tracks[4].duration, true)}`)]})
                } else if(i.values[6] === "s7") {
               player.queue.add(s.tracks[6]);
                    if(player && player.state === "CONNECTED" && !player.playing && !player.paused && !player.queue.size) await player.play();

                    if(msg) await msg.edit({embeds: [search.setAuthor({name:`Track Queue`}).setDescription(`[${s.tracks[6].title}](https://discord.gg/5hr4Ef776k) - ${convertTime(s.tracks[6].duration, true)}`)]})
                } else if(i.values[7] === "s8") {
               player.queue.add(s.tracks[7]);
                    if(player && player.state === "CONNECTED" && !player.playing && !player.paused && !player.queue.size) await player.play();

                    if(msg) await msg.edit({embeds: [search.setAuthor({name:`Track Queue`}).setDescription(`[${s.tracks[7].title}](https://discord.gg/5hr4Ef776k) - ${convertTime(s.tracks[7].duration, true)}`)]})
                } else if(i.values[8] === "s9") {
               player.queue.add(s.tracks[8]);
                    if(player && player.state === "CONNECTED" && !player.playing && !player.paused && !player.queue.size) await player.play();

                    if(msg) await msg.edit({embeds: [search.setAuthor({name:`Track Queue`}).setDescription(`[${s.tracks[8].title}](https://discord.gg/5hr4Ef776k) - ${convertTime(s.tracks[8].duration, true)}`)]})
                } else if(i.values[9] === "s10") {
               player.queue.add(s.tracks[9]);
                    if(player && player.state === "CONNECTED" && !player.playing && !player.paused && !player.queue.size) await player.play();

                    if(msg) await msg.edit({embeds: [search.setAuthor({name:`Track Queue`}).setDescription(`[${s.tracks[9].title}](https://discord.gg/5hr4Ef776k) - ${convertTime(s.tracks[9].duration, true)}`)]})
                }
 
            });
        break;
        case "PLAYLIST_LOADED":
            player.queue.add(s.tracks)
                const playlist = new EmbedBuilder()
                    .setAuthor({name:`Playlist Queue`})
                    .setDescription(`[${s.playlist.name}](${query})`)
                    .setColor(client.embedColor)
                    msg.edit({embeds: [playlist], components: [] });
            if(!player.playing) player.play()
       }
        
    }
}
 


