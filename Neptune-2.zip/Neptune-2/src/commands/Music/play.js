const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const { convertTime } = require("../../utils/convert.js");
const { Player } = require("erela.js");

module.exports = {
  name: "play",
  category: "Music",
  aliases: ["p"],
  description: "Plays audio from any supported source.",
  args: true,
  usage: "<song URL or name>",
  userPerms: [],
  owner: false,
  player: false,
  inVoiceChannel: true,
  sameVoiceChannel: true,
  execute: async (message, args, client, prefix) => {
    if (
      !message.guild.members.me.permissions.has(
        PermissionsBitField.resolve(["Speak", "Connect"])
      )
    )
      return message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(client.embedColor)
            .setDescription(
              `I don't have enough permissions to execute this command! Please give me permission to \`CONNECT\` or \`SPEAK\`.`
            ),
        ],
      });
    
    const { channel } = message.member.voice;
    if (
      !message.guild.members.cache
        .get(client.user.id)
        .permissionsIn(channel)
        .has(PermissionsBitField.resolve(["Speak", "Connect"]))
    )
      return message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(client.embedColor)
            .setDescription(
              `I don't have enough permissions connect your VC! Please give me permission to \`CONNECT\` or \`SPEAK\`.`
            ),
        ],
      });

    const emojiaddsong = message.client.emoji.addsong;
    const emojiplaylist = message.client.emoji.playlist;

    let player = client.manager.get(message.guild.id);

    if (!player) {
      player = await client.manager.create({
        guild: message.guild.id,
        voiceChannel: message.member.voice.channel.id,
        textChannel: message.channel.id,
        selfDeafen: true,
        volume: 80,
      });
    }

    if (player.state !== "CONNECTED") {
      await player.connect();
    }

    const search = args.join(" ");

    if (args.join(" ").includes(`https://youtu.be`) || args.join(" ").includes(`https://www.youtube.com/`)) {
      return message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription("This bot does not support YouTube links."),
        ],
      });
    }

    let res;
    try {
      res = await player.search(search, message.author);
      if (!res.tracks.length) {
        if (!player.queue.current) player.destroy();
        return message.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(client.embedColor)
              .setTimestamp()
              .setDescription(`❌ | No matches found for - ${search}`),
          ],
        });
      }
    } catch (err) {
      return message.reply(
        `There was an error while searching: ${err.message}`
      );
    }

    const track = res.tracks[0];

    player.queue.add(track);

    if (!player.playing && !player.paused && !player.queue.size) {
      player.play();
    } else {
      const embed = new EmbedBuilder()
        .setColor(client.embedColor)
        .setTimestamp()
        .setThumbnail(
          track.displayThumbnail("hqdefault") ?? (await client.manager.getMetaThumbnail(track.uri))
        )
        .setDescription(`**ADDED TO QUEUE**\n[${track.title}](${track.uri})\n\n**Requester: **<@${track.requester.id}> | **Duration: **\`❯ \`[${convertTime(track.duration)}]\``);

      return message.channel.send({ embeds: [embed] });
    }
  },
};
