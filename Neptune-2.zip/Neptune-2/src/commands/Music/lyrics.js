const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { findLyrics } = require("llyrics");

module.exports = {
  name: "lyrics",
  category: "Music",
  description: "Gets the lyrics of a song.",
  userPrems: [],
  usage: "<song name>",
  player: true,
  args: true,
  dj: false,
  inVoiceChannel: true,
  sameVoiceChannel: true,

  execute: async (message, args, client, prefix) => {
    const searchMsg = await message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(client.embedColor)
          .setDescription("**Searching...**"),
      ],
    });

    let player;
    if (client.manager) {
      player = client.manager.players.get(message.guild.id);
    } else {
      return message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(client.embedColor)
            .setDescription("Lavalink node is not connected."),
        ],
      });
    }

    if (!args.length && !player) {
      return message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(client.embedColor)
            .setDescription("There's no music playing."),
        ],
      });
    }

    let currentTitle = "";
    const phrasesToRemove = [
      "Full Video", "Full Audio", "Official Music Video", "Lyrics", "Lyrical Video",
      "Feat.", "Ft.", "Official", "Audio", "Video", "HD", "4K", "Remix", "Lyric Video",
      "Lyrics Video", "8K", "High Quality", "Animation Video", "\\(Official Video\\. .*\\)",
      "\\(Music Video\\. .*\\)", "\\[NCS Release\\]", "Extended", "DJ Edit", "with Lyrics",
      "Lyrics", "Karaoke", "Instrumental", "Live", "Acoustic", "Cover", "\\(feat\\. .*\\)"
    ];
    if (!args.length) {
      currentTitle = player.queue.current.title;
      currentTitle = currentTitle
        .replace(new RegExp(phrasesToRemove.join("|"), "gi"), "")
        .replace(/\s*([\[\(].*?[\]\)])?\s*(\|.*)?\s*(\*.*)?$/, "");
    }

    const query = args.length ? args.join(" ") : currentTitle;
    let lyricsData;
    try {
      lyricsData = await findLyrics({
        search_engine: { musixmatch: true, youtube: true, genius: false },
        song_title: query,
      });
    } catch (error) {
      return searchMsg.edit({
        embeds: [
          new EmbedBuilder()
            .setColor(client.embedColor)
            .setTitle("No lyrics found")
            .setDescription(
              `Here are some tips to get your song lyrics correctly:
1. Try to add the artist's name in front of the song name.
2. Try to search the lyrics manually by providing the song query using your keyboard.
3. Avoid searching lyrics in languages other than English.`
            ),
        ],
      });
    }

    function splitText(text, maxChunkLength) {
      const chunks = [];
      for (let i = 0; i < text.length; i += maxChunkLength) {
        chunks.push(text.slice(i, i + maxChunkLength));
      }
      return chunks;
    }

    const lyrics = lyricsData.lyrics;
    const trackName = lyricsData.trackName;
    const trackArtist = lyricsData.trackArtist;
    const artworkUrl = lyricsData.artworkUrl;
    const searchEngine = lyricsData.searchEngine;
    const pageLength = 2000;
    const pages = splitText(lyrics, pageLength);

    let currentPage = 0;

    const embed = new EmbedBuilder()
      .setColor(client.embedColor)
      .setTitle(`${trackName} - ${trackArtist}`)
      .setThumbnail(artworkUrl)
      .setDescription(pages[currentPage])
      .setFooter({ text: `Page: ${currentPage + 1}/${pages.length} | Search Engine: ${searchEngine}` });

    const deleteButton = new ButtonBuilder()
      .setEmoji({ id: "948552310504701982" })
      .setCustomId("delete_interaction")
      .setStyle(ButtonStyle.Danger);

    const row = createRow(currentPage, pages, deleteButton);

    const msg = await searchMsg.edit({
      embeds: [embed],
      components: [row],
    });

    const filter = async (button) => {
      if (button.user.id === message.author.id) return true;
      else {
        return button.reply({
          ephemeral: true,
          embeds: [
            new EmbedBuilder()
              .setColor(client.embedColor)
              .setDescription(
                `${client.e.crossMark} | This interaction button is only for <@${message.author.id}>.`
              ),
          ],
        });
      }
    };

    const collector = msg.createMessageComponentCollector({ filter });

    collector.on("collect", async (i) => {
      if (i.customId === "delete_interaction") {
        await i.deferUpdate();
        i.deleteReply().catch((err) => {
          return;
        });
        msg.delete().catch((err) => {
          return;
        });
      }
      if (i.customId === "next_interaction") {
        currentPage++;
        if (currentPage < pages.length) {
          const newEmbed = createEmbed(client.embedColor, trackName, trackArtist, artworkUrl, pages, currentPage, searchEngine);
          const newRow = createRow(currentPage, pages, deleteButton);

          await i.update({
            embeds: [newEmbed],
            components: [newRow],
          });
        }
      } else if (i.customId === "prev_interaction") {
        currentPage--;
        if (currentPage >= 0) {
          const newEmbed = createEmbed(client.embedColor, trackName, trackArtist, artworkUrl, pages, currentPage, searchEngine);
          const newRow = createRow(currentPage, pages, deleteButton);

          await i.update({
            embeds: [newEmbed],
            components: [newRow],
          });
        }
      }
    });
  },
};

function createEmbed(color, trackName, trackArtist, artworkUrl, pages, currentPage, searchEngine) {
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(`${trackName} - ${trackArtist}`)
    .setThumbnail(artworkUrl)
    .setDescription(pages[currentPage])
    .setFooter({ text: `Page: ${currentPage + 1}/${pages.length} | Search Engine: ${searchEngine}` });
}

function createRow(currentPage, pages, deleteButton) {
  const prevButton = new ButtonBuilder()
    .setCustomId("prev_interaction")
    .setEmoji("◀️")
    .setStyle(ButtonStyle.Primary)
    .setDisabled(currentPage === 0);

  const nextButton = new ButtonBuilder()
    .setCustomId("next_interaction")
    .setEmoji("▶️")
    .setStyle(ButtonStyle.Primary)
    .setDisabled(currentPage === pages.length - 1);

  return new ActionRowBuilder().addComponents(prevButton, nextButton, deleteButton);
}
