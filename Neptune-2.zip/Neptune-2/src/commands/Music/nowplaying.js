const { EmbedBuilder, AttachmentBuilder } = require("discord.js");
const { convertTime } = require('../../utils/convert.js');
const { progressbar } = require('../../utils/progressbar.js');
const { classicCard } = require("songcard");
const path = require("path");

module.exports = {
  name: "nowplaying",
  aliases: ["np"],
  category: "Music",
  description: "Show the current playing song.",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  player: true,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  execute: async (message, args, client, prefix) => {
    const player = message.client.manager.get(message.guild.id);

    if (!player.queue.current) {
      let thing = new EmbedBuilder()
        .setColor("Red")
        .setDescription("There is no music playing.");
      return message.channel.send({ embeds: [thing] });
    }

    const song = player.queue.current;
    const emojimusic = client.emoji.music;
    var total = song.duration;
    var current = player.position;

    const noBgURL = path.join(__dirname, "..", "..", "assets", "no_bg.png");

    const cardImage = await classicCard({
      imageBg: song.displayThumbnail("maxresdefault") || noBgURL,
      imageText: song.title,
      trackStream: song.isStream,
      trackDuration: player.position,
      trackTotalDuration: song.duration,
    });

    const attachment = new AttachmentBuilder(cardImage, { name: "card.png" });

    let embed = new EmbedBuilder()
      .setDescription(`${emojimusic} **Now Playing**\n [${song.title}](${song.uri})\n\n**Requester : **<@${message.author.id}>\n**Duration : ** \`[${convertTime(total)}]\``)
      .setThumbnail(song.displayThumbnail())
      .setColor(client.embedColor)
      .addFields([
        { name: 'Current', value: `\`${convertTime(current)} / ${convertTime(total)}\`` },
      ])
      .setImage("attachment://card.png");

    return message.channel.send({ embeds: [embed], files: [attachment] });
  }
};
