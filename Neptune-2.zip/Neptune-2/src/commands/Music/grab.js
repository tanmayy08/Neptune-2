const { EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder } = require("discord.js");
const { convertTime } = require("../../utils/convert.js");

module.exports = {
	name: "grab",
    aliases: ["save"],
    category: "Music",
    description: "Grabs And Sends You The Song That Is Playing At The Moment",
    args: false,
    userPerms: [],
    owner: false,
    dj: true,
    player: true,
    inVoiceChannel: true,
    sameVoiceChannel: true,
 execute: async (message, args, client, prefix) => {
       
        const player = message.client.manager.get(message.guild.id);

        if (!player.queue.current) {
            let thing = new EmbedBuilder()
                .setColor(client.embedColor)
                .setAuthor({name: `There Is No Music Playing`})
            return message.reply({embeds: [thing]});
        }

        let dm = new EmbedBuilder()
        .setDescription(`**Kindly Check Your DMs Please**`)
        .setColor(client.embedColor)
        .setTimestamp()

   const song = player.queue.current
        const total = song.duration;
        const current = player.position;
        let i = 1;

        let embed = new EmbedBuilder()
            .setAuthor({ name: `Song Details`})
            .setDescription(`**[${song.title}](https://discord.gg/5hr4Ef776k)**`)

            .addFields([{name:`Duration`, value: `${convertTime(total)}`, inline: false },
                        {name: `Author`, value: `${song.author}`},
                         {name: `Requester`, value: `[${message.author.username}](
https://discord.com/users/${message.author.id})`, inline: false}])
            .setThumbnail(message.author.displayAvatarURL( {dynamic : true }))
  .setImage(`${song.thumbnail}`)
        
            .setTimestamp()
            
         message.author.send({embeds: [embed]}).then(() => message.channel.send({embeds: [dm]})).catch((error) => {
           message.channel.send({embeds: [new EmbedBuilder.setColor(client.embedColor).setDescription(`**Your \`Direct Messages\` is **OFF**, turn it on and try again!**`).setTimestamp()]})
});
	
    }
};