const { EmbedBuilder } = require("discord.js");
const ServerPremium = require('../../schema/ServerPremium');
const TwentyFourSeven = require('../../schema/247');

module.exports = {
name: "config",
category: "Config",
aliases: ["serverconfig", "configuration"],
description: "View the server's custom configuration",
args: false,
usage: "",
userPerms: [],
owner: false,
execute: async (message, args, client, prefix) => {
const guildId = message.guild.id;

// Fetch the server's premium status from the database
const serverPremium = await ServerPremium.findOne({ guildId });

let premiumStatus = "Not Enabled";
let expiryDate = "N/A";

if (serverPremium && serverPremium.expiresAt > new Date()) {
premiumStatus = "Enabled";
expiryDate = serverPremium.expiresAt.toDateString();
}

// Fetch the server's 24/7 status from the database
const twentyFourSevenConfig = await TwentyFourSeven.findOne({ Guild: guildId });

let twentyFourSevenStatus = "Disabled";
let voiceChannel = "N/A";
let textChannel = "N/A";

if (twentyFourSevenConfig && twentyFourSevenConfig['247']) {
twentyFourSevenStatus = "Enabled";
voiceChannel = `<#${twentyFourSevenConfig.VoiceChannel}>` || "N/A";
textChannel = `<#${twentyFourSevenConfig.TextChannel}>` || "N/A";
}

// Create the embed message for the server configuration
const embed = new EmbedBuilder()
.setTitle(`Server Configuration for ${message.guild.name}`)
.addFields(
{ name: 'Premium Status', value: premiumStatus, inline: true },
{ name: 'Expiry Date', value: expiryDate, inline: true },
{ name: '24/7 Mode', value: twentyFourSevenStatus, inline: true },
{ name: 'Voice Channel', value: voiceChannel, inline: true },
{ name: 'Text Channel', value: textChannel, inline: true }
)
.setColor(client.color)
.setTimestamp();

// Send the embed message
await message.channel.send({ embeds: [embed] });
},
};