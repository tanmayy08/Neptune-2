const { EmbedBuilder } = require("discord.js");
const db = require("../../schema/playlist");

module.exports = {
    name: "playlist-create",
    aliases: ["plcreate"],
    category: "Playlist",
    description: "Creates the user's playlist.",
    args: true,
    usage: "Please Provide A Playlist Name To Create",
    userPerms: [],
    owner: false,
    player: false,
    inVoiceChannel: false,
    sameVoiceChannel: false,
    execute: async (message, args, client, prefix) => {

        var color = client.embedColor;
        const Name = args[0].replace(/_/g, ' ');
        if (Name[0].length < 0) {
            return message.reply({ embeds: [new EmbedBuilder().setColor(color).setDescription("Provide A Playlist Name")] });
        };

        if (Name.length > 100) {
            return message.reply({ embeds: [new EmbedBuilder().setColor(color).setDescription("Playlist Name Can't Be Greater Than \`100\` Characters.")] });
        };
        let data = await db.find({
            UserId: message.author.id,
            PlaylistName: Name,
        });

        if (data.length > 0) {
            return message.reply({ embeds: [new EmbedBuilder().setColor(color).setDescription(`This Playlist Already Exists`)] })
        };
        let userData = db.find({
            UserId: message.author.id
        });
        if (userData.length >= 10) {
            return message.reply({ embeds: [new EmbedBuilder().setColor(color).setDescription(`You Can Only Create Up To \`10\` Playlists.`)] })
        }

        const newData = new db({
            UserName: message.author.tag,
            UserId: message.author.id,
            PlaylistName: Name,
            CreatedOn: Math.round(Date.now() / 1000)
        });
        await newData.save();
        const embed = new EmbedBuilder()
            .setDescription(`Successfully Created A Playlist Named **${Name}**.`)
        .setFooter({

        text: `Try +playlist-start to start your playlist `,

        iconURL: client.user.displayAvatarURL({ dynamic: true }),

      })
        
            .setColor(color)
        return message.channel.send({ embeds: [embed] })

    }
};
