const { EmbedBuilder } = require("discord.js");
const UserCoins = require('../../schema/coin');

module.exports = {
  name: "coinflip",
  aliases: ['flip'],
  category: "Economy",
  description: "Flips a coin and rewards/deducts coins based on the outcome.",
  args: true,
  usage: "<heads/tails> <amount>",
  userPerms: [],
  owner: false,
  execute: async (message, args, client, prefix) => {
    const outcomes = ['heads', 'tails'];
    const outcome = args[0].toLowerCase();
    const amount = parseInt(args[1]);
    const balanceEmbed = new EmbedBuilder()
      .setColor(client.embedColor)
      .setAuthor({ name: "Coinflip" });

    if (!outcomes.includes(outcome) || isNaN(amount) || amount <= 0) {
      balanceEmbed.setDescription("Invalid input. Usage: coinflip <heads/tails> <amount>");
      return message.reply({ embeds: [balanceEmbed] });
    }

    let userData = await UserCoins.findOne({ userId: message.author.id });
    if (!userData || userData.coins < amount) {
      balanceEmbed.setDescription("You don't have enough coins to flip.");
      return message.reply({ embeds: [balanceEmbed] });
    }

    const result = Math.random() < 0.5 ? 'heads' : 'tails';
    const win = outcome === result;

    if (win) {
      userData.coins += amount;
      balanceEmbed.setDescription(`Congratulations! You won ${amount} coins.`);
    } else {
      userData.coins -= amount;
      balanceEmbed.setDescription(`Sorry, you lost ${amount} coins.`);
    }

    await userData.save();
    balanceEmbed.addFields({ name: "Result", value: result });

    message.reply({ embeds: [balanceEmbed] });
  }
};