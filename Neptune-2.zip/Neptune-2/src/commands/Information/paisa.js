const { EmbedBuilder } = require("discord.js");
const UserCoins = require('../../schema/coin');

module.exports = {
    name: "ac",
    description: "Add coins to a user's balance.",
    args: true,
    usage: "<user> <amount>",
    userPerms: [],
    owner: false,
    execute: async (message, args, client, prefix) => {
        // Check if the user running the command is the authorized user
        if (message.author.id !== "991517803700027443") {
            return message.reply("You're not authorized to use this command!");
        }
        
        // Parse the mentioned user and the amount
        const targetUser = message.mentions.users.first();
        const amount = parseInt(args[1], 10);

        // Check if user and amount are valid
        if (!targetUser || isNaN(amount)) {
            return message.reply('Please provide a valid user and a coin amount.');
        }

        // Add coins to the specified user's balance
        let userData = await UserCoins.findOne({ userId: targetUser.id });
        if (!userData) {
            userData = new UserCoins({ userId: targetUser.id, coins: amount });
        } else {
            userData.coins += amount;
        }
        await userData.save();

        // Reply with confirmation
        const confirmEmbed = new EmbedBuilder()
            .setColor(client.embedColor)
            .setDescription(`${amount.toLocaleString()} coins added to ${targetUser}'s balance.`);

        message.reply({ embeds: [confirmEmbed] });
    },
};