const { EmbedBuilder } = require("discord.js");
const UserCoins = require('../../schema/coin');
const PremiumMembers = require('../../schema/prem');

module.exports = {
  name: "buy",
  description: "Buy a premium membership using coins.",
  args: false,
  usage: "<plan>",
  userPerms: [],
  owner: false,
  execute: async (message, args, client, prefix) => {
    // Define premium plans with cool names and details
    const premiumPlans = {
      'express': { duration: 7 * 24 * 60 * 60 * 1000, coins: 500, name: 'Express Tune' },
      'melody': { duration: 28 * 24 * 60 * 60 * 1000, coins: 2000, name: 'Melody Month' },
      'harmony': { duration: 56 * 24 * 60 * 60 * 1000, coins: 4000, name: 'Harmony Hype' },
      'symphony': { duration: 112 * 24 * 60 * 60 * 1000, coins: 8000, name: 'Symphony Saga' },
      'infinite': { duration: Infinity, coins: 10000, name: 'Infinite Playlist' }
    };

    // If user doesn't specify a plan, list all plans
    if (args.length === 0) {
      let planDescriptions = Object.values(premiumPlans).map(plan => `<:R_arrow:1235529528483254334> **${plan.name}**: ${plan.coins} coins`).join('\n');
      let listEmbed = new EmbedBuilder()
        .setColor(client.embedColor)
        .setTitle("Premium Plan Options")
        .setDescription(planDescriptions);

      return message.reply({ embeds: [listEmbed] });
    }

    // User specified a plan, so let's process it
    const chosenPlanKey = args[0].toLowerCase();
    const chosenPlan = premiumPlans[chosenPlanKey];

    if (!chosenPlan) {
      return message.reply(`Please specify a valid plan: ${Object.keys(premiumPlans).join(', ')}.`);
    }

    let userData = await UserCoins.findOne({ userId: message.author.id });
    if (!userData) {
      return message.reply("You don't have any coins!");
    }

    if (userData.coins < chosenPlan.coins) {
      return message.reply(`You need at least ${chosenPlan.coins} coins to buy the ${chosenPlan.name} plan.`);
    }
    userData.coins -= chosenPlan.coins;
    await userData.save();

    let premiumData = await PremiumMembers.findOne({ userId: message.author.id });
    const newExpiryDate = new Date();
    if (chosenPlan.duration !== Infinity) {
      newExpiryDate.setTime(newExpiryDate.getTime() + chosenPlan.duration);
    } else {
      newExpiryDate.setFullYear(newExpiryDate.getFullYear() + 100); // Set to a far future date for lifetime
    }

    if (!premiumData) {
      premiumData = new PremiumMembers({
        userId: message.author.id,
        expiresAt: newExpiryDate
      });
    } else {
      premiumData.expiresAt = new Date(Math.max(premiumData.expiresAt, newExpiryDate));
    }
    await premiumData.save();

    const embed = new EmbedBuilder()
      .setColor(client.embedColor)
      .setTitle("Success!")
      .setDescription(`You have purchased the ${chosenPlan.name} plan. Enjoy your premium features!`);

    return message.reply({ embeds: [embed] });
  }
};    