const { EmbedBuilder } = require("discord.js");
const UserCoins = require('../../schema/coin');

module.exports = {
name: "balance",
aliases: ['bal', 'coins'],
category: "Utility",
description: "Displays the user's coin balance.",
args: false,
usage: "",
userPerms: [],
owner: false,
execute: async (message, args, client, prefix) => {
const targetUser = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
let userData = await UserCoins.findOne({ userId: targetUser.id });

if (!userData) {
userData = await new UserCoins({ userId: targetUser.id, coins: 10 }).save();
}

const balanceEmbed = new EmbedBuilder()
.setColor(client.embedColor)
.setAuthor({ name: `${targetUser.username}, you have total of ${userData.coins.toLocaleString()} Coins`, iconURL: targetUser.displayAvatarURL({ dynamic: true })})
.addFields({ name: `Need coins ? Here's how you can get them:`, value: `<:n_Giveaways:1237280007244746793>**For Freebies** :\n⠀⠀⠀Each cmd used (1-6 coins)\n⠀⠀⠀Add me in server (200 coins)\n<:nitro:1237280971913695315>**For Rich Kids**\n⠀⠀⠀Boost Support Server (1000 coins)\n⠀⠀⠀Pay 200k UwU (1000 coins)`, inline: true });

message.reply({ embeds: [balanceEmbed] });
}
}