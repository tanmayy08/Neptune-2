const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
  name: "invite",
  category: "Information",
  aliases: ["addme"],
  description: "Get the bot's invite link.",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  execute: async (message, args, client, prefix) => {
    var invite = client.config.links.invite;
    var support = client.config.links.support;

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setLabel("Invite")
          .setStyle(ButtonStyle.Link)
          .setURL(invite),
        new ButtonBuilder()
          .setLabel("Support")
          .setStyle(ButtonStyle.Link)
          .setURL(support)
      );

    const tanmayy = new EmbedBuilder()
      .setAuthor({ name: `Invite ${client.user.username}`, iconURL: client.user.displayAvatarURL()})
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter({text: `Love From Tanmay`,iconURL: client.user.displayAvatarURL()})
      .setColor(client.embedColor)
      .addFields([{ name: '<:invite_red:1256281612111450182> Invite Link', value: `[**${client.user.username}**](${invite})` },
      { name: '<:supports:1256281355516379156> Support Server', value: `[**Server link**](${support})`
                    }])
    
    message.reply({ embeds: [tanmayy], components: [row] })
  }
}
