const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ComponentType } = require("discord.js");
const PremiumMember = require("../../schema/prem");

module.exports = {
  name: "profile",
  category: "Information",
  aliases: ["pr"],
  description: "Shows user's profile",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  voteonly: false,
  execute: async (message, args, client, prefix) => {

   var support = client.config.links.support;
    let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;

    // Add your guild id where the roles are checked
    const guildd = await client.guilds.fetch("1190286720361582683"); 
    const member = await guildd.members.fetch(user.id).catch((e) => {});
// ... rest of the profile command code

const noPrefixStatus = await client.db.get(`noprefix_${user.id}`); // Check for no-prefix status
const premiumStatus = await PremiumMember.findOne({ userId: user.id });

let noPrefixActive = noPrefixStatus && new Date(noPrefixStatus) > new Date()? "<:n_tick:1191377412240441364>" : "<:n_cross:1191377533413904445>";
let premiumActive = premiumStatus && new Date(premiumStatus.expiresAt) > new Date()? "<:n_tick:1191377412240441364>" : "<:n_cross:1191377533413904445>";

// Calculate the no-prefix subscription length
let noPrefixExpiration;
let noPrefixSubscriptionLength;
if (noPrefixStatus) {
  noPrefixExpiration = new Date(noPrefixStatus);
  noPrefixSubscriptionLength = Math.abs(noPrefixExpiration - new Date()) / (1000 * 3600 * 24); // Convert to days
  if (noPrefixSubscriptionLength === Infinity) {
    noPrefixSubscriptionString = "`**Lifetime*`";
  } else {
    noPrefixSubscriptionString = `${Math.floor(noPrefixSubscriptionLength)} days`;
  }
} else {
  noPrefixSubscriptionString = "`**Not Activated**`";
}

// Calculate the premium subscription length
let premiumExpiration;
let premiumSubscriptionLength;
if (premiumStatus) {
  premiumExpiration = new Date(premiumStatus.expiresAt);
  premiumSubscriptionLength = Math.abs(premiumExpiration - new Date()) / (1000 * 3600 * 24); // Convert to days
  if (premiumSubscriptionLength === Infinity) {
    premiumSubscriptionString = "`**Lifetime**`";
  } else {
    premiumSubscriptionString = `${Math.floor(premiumSubscriptionLength)} days`;
  }
} else {
  premiumSubscriptionString = "`**Not Activated**`";
}


let badges = member ? (
    (member.roles.cache.has("1243068755664179250") ? "\n<:nc_OWNER:1243111738195316847> **Owner**" : "") +
    (member.roles.cache.has("1243068705689178185") ? "\n<:Developer:1243056270374735936> **Developer**" : "") +
    (member.roles.cache.has("1243068807434735658") ? "\n<:yug_admin:1243055839040766094> **Admin**" : "") +
(member.roles.cache.has("1243071118827458611") ? "\n<:Humanity_owners_heart:1243056162828714030> **Special**" : "") +
    (member.roles.cache.has("1243071118827458611") ? "\n<:stars:1235529667004465203> **Friends**" : "") +
    (member.roles.cache.has("1243068988637057034") ? "\n<:officials:1243074982133760101> **Official**" : "") +

    (member.roles.cache.has("1243068900166340658") ? "\n<:69creator_developing_bot:1243063728870653973> **Bot User**" : "")
) : "";
let privilege = member ? (
(member.roles.cache.has("1234907745337999371") ? "\n**Vote Bypass**: <:n_tick:1191377412240441364>" : "")

) : "";
privilege += `\n\n**No-Prefix**: ${noPrefixActive}`;
privilege += `\n**No-Prefix Status:** ${noPrefixSubscriptionString}`;
privilege += `\n\n**Premium**: ${premiumActive}`;
privilege += `\n**Premium Status:** ${premiumSubscriptionString}`;
    
     const Neptune2 = client.users.cache.get(`991517803700027443`);
     const Neptune = client.users.cache.get(`991517803700027443`);
     
     const home = new EmbedBuilder()
              .setAuthor({ name: `${user.tag}'s Profile.`, iconURL: message.guild.iconURL({ dynamic: true, size: 2048 })})
              .setDescription(`${badges.length ? badges : `Oops! Looks Like You Don't Have Any Type Of Badge To Be Displayed! You Can Get One By Joining Our [Support Server](${support})`}`)
              .setColor(client.color)
              .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
              .setFooter({ text: `Requested by `+ message.author.username, iconURL: message.author.displayAvatarURL({ dynamic: true })})

     const row = new ActionRowBuilder().addComponents([
       new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId("home").setLabel("Main").setEmoji('1247839772769128459'),
       new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId("Neptune2").setLabel(`Premium Info`).setEmoji("1247839657916633199"),

       ]);
     const msg = await message.channel.send({ embeds: [home], components: [row] });
    
    const collector = msg.createMessageComponentCollector({
      filter: (i) => {
        if (message.author.id === i.user.id) return true;
        else {
          i.reply({
            content: `${client.emoji.cross} | That's not your session. Run \`${prefix}profile\` to create your own.`,
            ephemeral: true,
          });
        }
      },
      time: 60000,
    })


     collector.on('collect', async (i) => {
       if (i.customId === 'Neptune2') {
         const embed = new EmbedBuilder().setAuthor({ name: `${user.tag}'s Profile.`, iconURL: message.guild.iconURL({ dynamic: true, size: 2048 })})
           .setFooter({  text: `Thanks For Using Me <3`, iconURL: message.author.displayAvatarURL()})
           .setDescription(`${privilege.length ? privilege : `No privilege to display.`}`)
           .setThumbnail(Neptune2.displayAvatarURL({ dynamic: true, size: 2048 }))
           .setColor(client.color)
           .setTimestamp()
           i.update({ embeds: [embed], components: [row] });
       } else if (i.customId === 'noob') {
         const embed = new EmbedBuilder()
           .setAuthor({ name: '.', iconURL: message.guild.iconURL({ dynamic: true, size: 2048 })})
           .setFooter({  text: `Thanks For Using Me <3`, iconURL: message.author.displayAvatarURL()})
           .setDescription(`> `)
           .setThumbnail(Neptune.displayAvatarURL({ dynamic: true, size: 2048 }))
           .setColor(client.color)
           .setTimestamp()
           i.update({ embeds: [embed], components: [row] });
       } else if (i.customId === 'home') {
      i.update({ embeds: [home], components: [row] });
       }
     })
   }
}