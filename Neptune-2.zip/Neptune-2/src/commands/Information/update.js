const { EmbedBuilder } = require("discord.js");
const moment = require("moment");
require("moment-duration-format");

module.exports = {
  name: "updates",
  
  aliases: ['update'],
  category: "Information",
  description: "Displays the bot's ping.",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  execute: async (message, args, client, prefix) => {
      const ping = client.ws.ping;
 
    const u1 = moment
      .duration(message.client.uptime)
      .format(" d [days], h [hrs], m [mins], s [secs]");
     
      let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;

      const PingEmbed = new EmbedBuilder()

        .setColor(client.embedColor)

        .addFields([
         { name: 'My Recent Updates', value: '<:icons_red:1256281752582885529> No Updates found', inline: true },
          ])

      message.reply({
        embeds: [PingEmbed]
      })
   }
}
