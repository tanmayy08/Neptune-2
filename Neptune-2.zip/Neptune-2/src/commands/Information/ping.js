const { EmbedBuilder } = require("discord.js");
const moment = require("moment");
require("moment-duration-format");

module.exports = {
  name: "ping",
  
  aliases: ['uptime', 'misc'],
  category: "Information",
  description: "Displays the bot's ping.",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  execute: async (message, args, client, prefix) => {
      const ping = client.ws.ping;
 
    const u1 = moment
      .duration(message.client.uptime)
      .format(" d [days], h [hrs], m [mins], s [secs]");
     
      let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;

const PingEmbed = new EmbedBuilder()
.setAuthor({ name: `Misc Radiowaves`, iconURL: user.displayAvatarURL({dynamic: true })})
.setColor(client.color) // A warm, vintage brown shade
.addFields([
{ name: '<:emoji_34:1256276533492973652> Ping', value: `*${ping}* ms`, inline: false },
{ name: '<:uptime:1256292068377100469> Uptime', value: `*${u1}*`, inline: false },
])
.setFooter({ text: `Tunes from Tanmay's Time Machine`, iconURL: user.displayAvatarURL({dynamic: true })})
.setThumbnail('https://example.com/vintage-microphone.jpg') // Placeholder for a vintage microphone or radio; replace with your image URL
.setDescription("Step back in time with every command. Neptune's retro vibes are here to deliver nostalgia, wrapped in modern tech.")

      message.reply({
        embeds: [PingEmbed]
      })
   }
}
