const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const canvafy = require("canvafy");

module.exports = {
  name: "ship",
  category: "Information",
  aliases: ["lovecalc"],
  description: "Get the bot's invite link.",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  execute: async (message, args, client, prefix) => {
   let member = message.mentions.members.first()
   if(!member)return message.reply({content:"Please mention someone."})

    const ship = await new canvafy.Ship()
    .setAvatars(message.author.displayAvatarURL({ forceStatic: true, extension: "png" }),member.user.displayAvatarURL({ forceStatic: true, extension: "png" }))
    .setBackground("image", "https://media.discordapp.net/attachments/1234424099481063464/1237583600980070440/pngtree-pink-romantic-aesthetic-wedding-marriage-fair-fair-flower-taobao-picture-image_1061517.jpg?ex=663c2d0b&is=663adb8b&hm=43e582825776544f1a918273117483b15a2823164a9f5b0ecb80d883ab75e104&")
    .setBorder("#f0f0f0")
    .setOverlayOpacity(0.5)
    .build();

    message.reply({
      files: [{
        attachment: ship,
        name: `ship-${message.member.id}.png`
      }]
    })
   }
}
