const { prefix } = require("../../config.js");
const { EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder, SelectMenuBuilder } = require("discord.js");

module.exports = {
    name: "help",
    category: "Information",
    aliases: [ "h" ],
    description: "Help with all commands, or one specific command.",
    args: false,
    usage: "",
    userPerms: [],
    owner: false,
 execute: async (message, args, client, prefix) => {
        if (args.length) {
            const commandName = args[0].toLowerCase();
            const command = client.commands.get(commandName) || client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));
            
            if (!command) {
                return message.reply("**That command doesn't exist!**");
            }
            
            // Create detailed embed for the command
            let commandEmbed = new EmbedBuilder()
                .setColor(client.embedColor)
                .setTitle(`Command: ${prefix}${command.name}`)
                .addFields(
                    { name: '<:Red_Arrow:1256282003381420053> Description', value: command.description || "No description provided." },
                    { name: '<:Red_Arrow:1256282003381420053> Usage', value: `${prefix}${command.name} ${command.usage}` },
                    { name: '<:Red_Arrow:1256282003381420053> Aliases', value: command.aliases?.join(", ") || "No aliases." },
                    { name: '<:Red_Arrow:1256282003381420053> Category', value: command.category || "No category." },
                )
                .setFooter({ text: 'Designed With Expertise By Uvii', iconURL: client.user.displayAvatarURL({dynamic: true}) });
            
            return message.reply({ embeds: [commandEmbed] });
        }
   var icon = client.config.links.icon;
   const ping = message.client.emoji.ping;
   const music = message.client.emoji.music;
   const filter = message.client.emoji.filter;
   const playlist = message.client.emoji.playlist;
   const info = message.client.emoji.info;
   const utility = message.client.emoji.utility;
   const setting = message.client.emoji.setting;
   const embed = new EmbedBuilder()
.setColor("#7f8c8d") // A classic, muted slate color for a timeless aesthetic
.setAuthor({ name: "Neptune 2's Help Desk", iconURL: 'https://cdn.discordapp.com/avatars/1190895731096178788/a_5ebaf4f29361c535b817fd3521e8b4eb.gif?size=2048' }) // Replace with your bot's icon URL
.setDescription(`**Hey! <@${message.author.id}>, welcome to my Help Desk.**`)
.addFields([
  { name: '<:supports:1256281355516379156> **Get Help:**', value: `<:icons_red:1256281752582885529> \`${prefix}help <command>\` - Learn more about a specific command.`, inline: false },
  { name: '**Module Navigation:**', value: `> <:dn_music:1256279826390712382> **Music**\n> <:filters:1256279951229980762> **Filters**\n> <:dn_playlist:1256280206587592755> **Playlist**\n> <:dn_config:1256280429057802401> **Settings**\n> <:dn_info:1256280166901223486> **Information**`, inline: false }    
])
.setFooter({ text: "Neptune's Help Desk | Experience the Rhythm"});
                
   let Tanmay2 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`music`).setEmoji(`${music}`),
            new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`filters`).setEmoji(`${filter}`),
            new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`playlist`).setEmoji(`${playlist}`),
            new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`info`).setEmoji(`${info}`),
            new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`utility`).setEmoji(`${utility}`)
        );
        
      let Tanmay20 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`delete`).setEmoji(`<:delete:1235530894169735219>`),
            new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`home`).setEmoji(`<:icons_home:1237747962688438292>`),
            new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`all`).setEmoji(`<:reason2:1235531080640237629>`)
      );
    const Tanmay3 = new ActionRowBuilder()
      .addComponents(
    new SelectMenuBuilder()
        .setCustomId("help_pop")
        .setPlaceholder('Dive into the options')
        .addOptions([
          {
              label: 'Music',
              value: 'music1',
              emoji: `${music}`,
          },
          {
              label: 'Filters',
              value: 'filters1',
              emoji: `${filter}`,
          },
          {
              label: 'Playlist',
              value: 'playlist1',
              emoji: `${playlist}`,
            },
            {
              label: 'Information',
              value: 'info1',
              emoji: `${info}`,
            },
            {
              label: 'Utility',
              value: 'utility1',
              emoji: `${utility}`,
            },
            {
              label: 'Settings',
              value: 'config1',
              emoji: `${setting}`,
            },
            {
              label: 'Home',
              value: 'embed',
              emoji: `<:icons_home:1237747962688438292>`,
            }
        ])
      )

   let _commands;
   
    const msg = await message.reply({ embeds: [embed], components: [Tanmay20, Tanmay3]});

   let page = 0;
   _commands1 = client.commands.filter((x) => x.category && x.category === "Music").map((x) => `\`${x.name}\``);
   _commands2 = client.commands.filter((x) => x.category && x.category === "Filters").map((x) => `\`${x.name}\``);
   _commands3 = client.commands.filter((x) => x.category && x.category === "Playlist").map((x) => `\`${x.name}\``);
   _commands4 = client.commands.filter((x) => x.category && x.category === "Information").map((x) => `\`${x.name}\``);
   _commands5 = client.commands.filter((x) => x.category && x.category === "utility").map((x) => `\`${x.name}\``);
   _commands6 = client.commands.filter((x) => x.category && x.category === "Config").map((x) => `\`${x.name}\``);

         let embed1 = new EmbedBuilder().setColor(client.embedColor).setDescription(_commands1.join(", ")).setAuthor({name : `Music Commands` , iconURL : message.member.displayAvatarURL()}).setImage(`https://media.discordapp.net/attachments/1190892172594135052/1254387068776218725/IMG_20240623_161405.png?ex=66794e7e&is=6677fcfe&hm=501bf392657f0a0c5bfce990dfaf4be292e28e86c0b1f1433d1f39243418af0a&`).setFooter({text: `Love From Tanmay. <3`, iconURL: client.user.displayAvatarURL({dynamic:true})})
        let embed2 = new EmbedBuilder().setColor(client.embedColor).setDescription(_commands2.join(", ")).setAuthor({name : `Filters Commands` , iconURL : message.member.displayAvatarURL()}).setImage(`https://media.discordapp.net/attachments/1190892172594135052/1254387068776218725/IMG_20240623_161405.png?ex=66794e7e&is=6677fcfe&hm=501bf392657f0a0c5bfce990dfaf4be292e28e86c0b1f1433d1f39243418af0a&`).setFooter({text: `Love From Tanmay. <3`, iconURL: client.user.displayAvatarURL({dynamic:true})})
        let embed3 = new EmbedBuilder().setColor(client.embedColor).setDescription(_commands3.join(", ")).setAuthor({name : `Playlist Commands` , iconURL : client.user.displayAvatarURL()}).setImage(`https://media.discordapp.net/attachments/1190892172594135052/1254387068776218725/IMG_20240623_161405.png?ex=66794e7e&is=6677fcfe&hm=501bf392657f0a0c5bfce990dfaf4be292e28e86c0b1f1433d1f39243418af0a&`).setFooter({text: `Love From Tanmay. <3`, iconURL: client.user.displayAvatarURL({dynamic:true})})
        let embed4 = new EmbedBuilder().setColor(client.embedColor).setDescription(_commands4.join(", ")).setAuthor({name : `Information Commands` , iconURL : client.user.displayAvatarURL()}).setImage(`https://media.discordapp.net/attachments/1190892172594135052/1254387068776218725/IMG_20240623_161405.png?ex=66794e7e&is=6677fcfe&hm=501bf392657f0a0c5bfce990dfaf4be292e28e86c0b1f1433d1f39243418af0a&`).setFooter({text: `Love From Tanmay. <3`, iconURL: client.user.displayAvatarURL({dynamic:true})})
        let embed5 = new EmbedBuilder().setColor(client.embedColor).setDescription(_commands5.join(", ")).setAuthor({name : `Utility Commands` , iconURL : client.user.displayAvatarURL()}).setImage(`https://media.discordapp.net/attachments/1190892172594135052/1254387068776218725/IMG_20240623_161405.png?ex=66794e7e&is=6677fcfe&hm=501bf392657f0a0c5bfce990dfaf4be292e28e86c0b1f1433d1f39243418af0a&`).setFooter({text: `Love From Tanmay. <3`, iconURL: client.user.displayAvatarURL({dynamic:true})})
   let embed6 = new EmbedBuilder().setColor(client.embedColor).setDescription(_commands6.join(", ")).setAuthor({name : `Settings Commands` , iconURL : client.user.displayAvatarURL()}).setImage(`https://media.discordapp.net/attachments/1190892172594135052/1254387068776218725/IMG_20240623_161405.png?ex=66794e7e&is=6677fcfe&hm=501bf392657f0a0c5bfce990dfaf4be292e28e86c0b1f1433d1f39243418af0a&`).setFooter({text: `Love From Tanmay. <3`, iconURL: client.user.displayAvatarURL({dynamic:true})})
   const mz = _commands1.join(", ")
   const mz2 = _commands2.join(", ")
   const mz3 = _commands3.join(", ")
   const mz4 = _commands4.join(", ")   
   const mz5 = _commands5.join(", ")   
   const mz6 = _commands6.join(", ")   
   
   let embed7 = new EmbedBuilder().setColor(client.embedColor).setAuthor({name : `All Commands` , iconURL : client.user.displayAvatarURL()}).addFields([
  { name: '__Music Commands__', value: `${mz}`, inline: false },
  { name: '__Filters Commands__', value: `${mz2}`, inline: false },
  { name: '__Playlist Commands__', value: `${mz3}`, inline: false },
  { name: '__Information Commands__', value: `${mz4}`, inline: false },
  { name: '__Utility Commands__', value: `${mz5}`, inline: false },
  { name: '__Settings Commands__', value: `${mz6}`, inline: false },
]).setFooter({text: `Let's get musical!!`, iconURL: client.user.displayAvatarURL({dynamic:true})})
   
        var embeds = [];
        embeds.push(embed1);embeds.push(embed2);embeds.push(embed3);embeds.push(embed4);embeds.push(embed5);embeds.push(embed6);embeds.push(embed7);

        const collector = await msg.createMessageComponentCollector({
            filter :(i) => {
                if(message.author.id === i.user.id) return true;
                else{
                    i.reply({content : `That's not your session run : \`${prefix}help\` to create your own.` , ephemeral : true})
                }
            },
            time : 1000000,
            idle : 1000000/2
        });

        collector.on('collect', async(i) => {
            if(i.isSelectMenu())
            {
                for(const value of i.values)
                {
                    if(value === `music1`)
                    {
                        return i.update({embeds : [embed1], ephemeral: true });
                    }
                    if(value === `filters1`)
                    {
                        return i.update({embeds : [embed2], ephemeral: true });
                    }
                    if(value === `playlist1`)
                    {
                        return i.update({embeds : [embed3], ephemeral: true });
                    }
                    if(value === `info1`)
                    {
                        return i.update({embeds : [embed4], ephemeral: true });
                    }
                    if(value === `utility1`)
                    {
                        return i.update({embeds : [embed5], ephemeral: true });
                    }
                    if(value === `config1`)
                    {
                        return i.update({embeds : [embed6], ephemeral: true });
                    }
                    if(value === `embed`)
                    {
                        return i.update({embeds : [embed], ephemeral: true })
                    }
                }
            }
            if(i.isButton())
            {
                if(i.customId === `music`)
                {
                    return i.update({embeds : [embed1], ephemeral: true });
                }
                if(i.customId === `filters`)
                {
                    return i.update({embeds : [embed2], ephemeral: true });
                }
                if(i.customId === `delete`)
                {
                    return i.message.delete();
                }
                if(i.customId === `home`)
                {
                    return i.update({embeds : [embed], ephemeral: true })
                }
                if(i.customId === `all`)
                {
                    return i.update({embeds : [embed7], ephemeral: true })
                }
                if(i.customId === `playlist`)
                {
                    return i.update({embeds : [embed3], ephemeral: true })
                }
                if(i.customId === `info`)
                {
                    return i.update({embeds : [embed4], ephemeral: true })
                }
                if(i.customId === `utility`)
                {
                    return i.update({embeds : [embed5], ephemeral: true });
                }
            }
        });
   }
  }