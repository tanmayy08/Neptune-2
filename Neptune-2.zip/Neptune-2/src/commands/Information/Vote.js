const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
  name: "vote",
  category: "Information",
  aliases: ["voteme"],
  description: "Get the bot's invite link.",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  execute: async (message, args, client, prefix) => {
    var invite = "https://top.gg/bot/1190895731096178788"

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setLabel("vote here")
          .setStyle(ButtonStyle.Link)
          .setURL(invite)
      );


    
    message.reply({ components: [row], content: "Here You Go!"})
  }
}
