const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
name: "about",
category: "Information",
description: "Dive into the world of Neptune!",
aliases: ['bi', 'botinfo'],
args: false,
usage: "",
userPerms: [],
owner: false,
execute: async (message, args, client, prefix) => {
const guildsCount = client.guilds.cache.size;
const userCount = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);
const invite = client.config.links.invite;
const support = client.config.links.support;

const row = new ActionRowBuilder()
.addComponents(
new ButtonBuilder()
.setLabel("🚀 Invite Neptune")
.setStyle(ButtonStyle.Link)
.setURL(invite),
new ButtonBuilder()
.setLabel("💬 Join the Chorus")
.setStyle(ButtonStyle.Link)
.setURL(support)
);

const botEmbed = new EmbedBuilder()
.setColor(client.color) // A lively, attractive pink
.setAuthor({ name: '🎵 Neptune 2 - The Sonic Alchemist', iconURL: client.user.displayAvatarURL()})
.setDescription("🌌 **Journey through the Galaxies of Groove with Neptune 2!** 🌌\nEmbark on an astral expedition where every note transcends the ordinary, transforming your Discord server into a concert hall spanning the cosmos.")
.addFields(
{ name: '👾 Galactic Presence', value: `Currently resonating across **${guildsCount.toLocaleString()}** servers`, inline: true },
{ name: '🎤 Enthralled Audience', value: `Performing for **${userCount.toLocaleString()}** listeners`, inline: true },
{ name: '⚡ Electrified Response', value: `Latency at ${client.ws.ping}ms`, inline: true }
)
.setThumbnail(client.user.displayAvatarURL())
.setFooter({ text: `🎶 Let's get musical! Brought to you by Tanmay | ${new Date().getFullYear()}`, iconURL: message.author.displayAvatarURL() })
.setTimestamp();

// Respond with the more vibrant and engaging Embed and Buttons
message.reply({ embeds: [botEmbed], components: [row] });
}
}